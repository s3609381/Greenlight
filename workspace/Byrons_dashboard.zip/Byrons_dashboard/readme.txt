Welcome to Byrons Dashboard, 

I have created a simple login page using PDO that connects to the MySQL database. From there I am running a small MySQL script that grabs 
the demo username and password. This is for demostration purposes only. I would expect that within your Web Application, multiple user types (i.e admin and normal user)
would be catered for. 

Credientials to login:
Username: demo
Password: demo

Once you have logged in, you will be redirected to the Dashboard which has 3 small features.
- A simple welcoming message which is a session echo of the current user who is logged in.
- A button called "View session", this will redirect you to session_dump.php file which dumps all data within the session.
- And last but not least a sign out button.

Going straight to the dashboard will redirect you back to the index page, unless you're logged in.

To use the PDO connection details, you just need to simply include the config.php file at the start of the page.


I have given you the basics to get started with your Web Application, Goodluck.


Kind Regards,
Byron Fisher
